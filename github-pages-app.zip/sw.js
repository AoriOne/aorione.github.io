/* App assets only. Images and inference inputs never enter this cache. */
const CACHE='dermometr-app-v3';
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const name of await caches.keys())if(name.startsWith('dermometr-app-')&&name!==CACHE)await caches.delete(name);await self.clients.claim();})()));
self.addEventListener('fetch',event=>{
  const request=event.request,url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin||url.search)return;
  const scope=new URL(self.registration.scope).pathname;
  const documentRequest=request.mode==='navigate'&&url.pathname.replace(/\/$/,'')===scope.replace(/\/$/,'');
  const asset=/\.(?:js|mjs|css|woff2|ttf|png|webmanifest)$/.test(url.pathname)||url.pathname.startsWith('/runtime/');
  if(!documentRequest&&!asset)return;
  // Never cache account/authentication routes or user-selected blobs.
  if(url.pathname.startsWith('/api/')||url.pathname.includes('/auth/'))return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    if(!documentRequest){const cached=await cache.match(request);if(cached)return cached;}
    try{const response=await fetch(request);if(response.ok&&!response.redirected&&response.type!=='opaque'){const copy=response.clone();event.waitUntil(cache.put(request,copy).catch(()=>{}));}return response;}
    catch(error){const cached=await cache.match(request);if(cached)return cached;if(documentRequest){const shell=await cache.match(new URL(scope,self.location.origin));if(shell)return shell;}throw error;}
  })());
});
