# Дерьмометр: локальные нейросети

Установка для разработки: `node scripts/download-dermometr-models.mjs` из корня репозитория. Скрипт загружает только фиксированные файлы моделей и проверяет каждый SHA-256 по `manifest.json`. Он не принимает изображения и не запускает удалённый inference.

Полный набор весов, конфигураций и токенизаторов занимает **983 077 950 байт**. ONNX Runtime Web Asyncify загружается в gzip (6 625 594 байта), распаковывается только в памяти: полный комплект вместе с приложением меньше 1 GB укладывается в предел 1 GB. Скрипт резервирует 12 MB под runtime и отказывается превышать 1 000 000 000 байт.

| Модель | Назначение | Зафиксированная версия |
| --- | --- | --- |
| [HuggingFaceTB/SmolVLM-256M-Instruct](https://huggingface.co/HuggingFaceTB/SmolVLM-256M-Instruct) | Изображение и текст → описание / ответ; embed_tokens q8, vision_encoder и decoder_model_merged q4f16 | `7e3e67edbbed1bf9888184d9df282b700a323964` |
| [Xenova/opus-mt-en-ru](https://huggingface.co/Xenova/opus-mt-en-ru) | Нейронный перевод английского ответа на русский; encoder и merged decoder q8 | `e050376e960175e8ddc5cff85025dc8436cddd68` |
| [szFangshi/tiny-sd-int8](https://huggingface.co/szFangshi/tiny-sd-int8) | Предобученные квантованные UNet и CLIP для настоящего img2img | `d333d4f2a8e9b2a6d77904961d02bfca45345093` |
| [julienkay/taesd](https://huggingface.co/julienkay/taesd) | Нейронное кодирование исходника и декодирование результата | `c8a437fd0201c21c3bcd298fcf3181b063bcc1eb` |
| [Xenova/clip-vit-large-patch14](https://huggingface.co/Xenova/clip-vit-large-patch14) | Совместимый CLIP BPE tokenizer.json; проверено совпадение всех 49 408 элементов словаря | `c307790166907339eed5a9a53a249af534102536` |

[Xenova/opus-mt-ru-en](https://huggingface.co/Xenova/opus-mt-ru-en), ревизия `afe8c6c738ec81b6d033fd8f44f9678a639a7c67`, переводит входящие русские сообщения в английский локально; encoder и merged decoder q8. Лицензия исходной Helsinki-NLP/opus-mt-ru-en — Apache-2.0. Общая история передаётся языковой модели, а не заменяется общей инструкцией.

[HuggingFaceTB/SmolLM2-135M-Instruct](https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct), ревизия `12fd25f77366fa6b3b4b768ec3050bf629380bac`, обслуживает разговор и код отдельно от зрения. Используется ONNX q4f16; Apache-2.0. Технические имена и код защищены от искажения входящим переводчиком.

SmolVLM официально является англоязычной моделью. Русский вывод обеспечивается отдельным локальным переводчиком. Нейронное редактирование использует отдельный Tiny-SD: исходное изображение кодируется TAESD, зашумляется и восстанавливается UNet с текстовым условием, затем декодируется обратно. Это настоящий img2img, а не готовые наклейки. Ограниченный размер моделей и 256 px дают грубые, непредсказуемые детали. Модели не обучаются при просмотре файлов.

Upstream INT8 UNet содержит 50 некорректных QLinearConv узлов. `tiny-sd-unet-repair.json` содержит воспроизводимое исправление protobuf: восстановлены Conv с DequantizeLinear из существующих обученных INT8-весов, удалены 100 некорректных Cast/Mul узлов. Веса не изменяются. Проверяются SHA-256 исходного файла и исправленного графа. Исправление применяется локально при загрузке; отдельный большой исправленный файл скачивать не нужно. Протестированы полный img2img на CPU и UNet inference через ONNX Runtime Web WASM. Из-за DynamicQuantizeLinear/MatMulInteger генерация использует WASM; WebGPU для этого графа не гарантирует ускорение.

SmolVLM распространяется под Apache-2.0. Исходная модель перевода [Helsinki-NLP/opus-mt-en-ru](https://huggingface.co/Helsinki-NLP/opus-mt-en-ru) также отмечена Apache-2.0. Атрибуция авторов и ссылки сохранены здесь; ONNX-конверсия перевода выполнена Xenova.

Tiny-SD происходит от [segmind/tiny-sd](https://huggingface.co/segmind/tiny-sd), лицензия CreativeML Open RAIL-M: текст сохранён в `TINY-SD-LICENSE.md`. Квантованная конверсия: szFangshi. TAESD: Ollin Boer Bohan, MIT, текст в `TAESD-LICENSE`; ONNX-конверсия julienkay. Приложение сохраняет эти условия и атрибуцию при распространении.

Большие веса и `ready.json` не следует коммитить в обычный Git: файл декодера превышает ограничение GitHub 100 MB. `ready.json` создаётся установщиком только после проверки всех файлов. Для размещения без весов приложение может загружать те же фиксированные публичные файлы; изображения остаются в браузере.
